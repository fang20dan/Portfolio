// PID: 730394638
// I pledge the COMP 211 honor code.

#include "bit_utils.h"

char* itob(int num, int size){ 
    //declaration of variables used, new var is signChecker which checks to see if value is negative or positive
    char *p;
    //allocating memory for pointer p
    p = (char *) malloc(sizeof(char)*size);
    int rem;
    int count = size - 1;
    int signChecker = 0;

    //checking to see if number is positive or negative for later two's complementing
    if(num<0){
        signChecker = 1;
    }
    else{
        signChecker = 0;
    }

    num = abs(num);

    //converting integer to bit and adding bit to pointer location
    while(count >= 0){
        rem = num % 2;
        p[count] = rem + '0';
        num = (num-rem)/2;
        count--;
    }
    //converting to negated version if negative
    if(signChecker == 1){
        for(int i = 0; i < size; i++){
            if(p[i] == '0'){
                p[i] = '1';
            }
            else if(p[i] == '1'){
                p[i] = '0';
            }
        }
        for(int i = size-1; i >= 0; i--){
            if(i == size-1 && p[i] == '1'){
                p[i] = '0';
                p[i-1] +=1;
            }
            else if(i == size-1 && p[i] == '0'){
                p[i] = '1';
            }
            if(p[i] > '1'){
                p[i] = '0';
                p[i-1] += 1;
            }
        }
    }
    return p;
}
//mask is bitwise AND
int mask_bits(int operateNum, int maskingBits){
    return operateNum&maskingBits;
}
//set is bitwise OR
int set_bits(int operateNum, int setBits){
    return operateNum|setBits;
}
//inverse is bitwise XOR
int inverse_bits(int operateNum, int inverseBits){
    return operateNum^inverseBits;
}
//logical shifts
int bit_select(int bit, int mSB, int lSB){
    unsigned int num = (unsigned int) bit;
    return (num >> (lSB)) & ~(~0 << (mSB - lSB + 1));
}

