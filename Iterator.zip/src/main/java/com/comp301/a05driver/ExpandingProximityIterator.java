package com.comp301.a05driver;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ExpandingProximityIterator implements Iterator {
    private Driver nextDriver;
    private Iterator<Driver> iterablePool;
    private int currentUpperRange;
    private int currentLowerRange;
    private Position currentPos;
    private int nextCount;
    private int poolSize;
    private int step;
    private boolean check;
    private Iterable<Driver> pool;
    private int times;

    public ExpandingProximityIterator(Iterable<Driver> driverPool, Position clientPosition, int expansionStep){
        if(driverPool == null || clientPosition == null){
            throw new IllegalArgumentException();
        }
        this.pool = driverPool;
        this.iterablePool = pool.iterator();
        this.nextDriver = null;
        this.step = expansionStep;
        this.times = 0;
        this.currentLowerRange = 0;
        this.currentUpperRange = 1 + times * this.step;
        this.currentPos = clientPosition;
        this.nextCount = 0;
        this.poolSize = 0;
        while(this.iterablePool.hasNext()){
            this.poolSize++;
            this.iterablePool.next();
        }
        this.iterablePool = pool.iterator();
        this.check = false;
    }

    private void loadNext(){
            while(this.nextDriver == null && this.iterablePool.hasNext()){
                Driver nextDriv = this.iterablePool.next();
                if(nextDriv.getVehicle().getPosition().getManhattanDistanceTo(this.currentPos) <= this.currentUpperRange &&
                        nextDriv.getVehicle().getPosition().getManhattanDistanceTo(this.currentPos) > this.currentLowerRange){
                    this.nextDriver = nextDriv;
                }
                else if(nextDriv.getVehicle().getPosition().getManhattanDistanceTo(this.currentPos) > this.currentUpperRange){
                    this.check = true;
                }
            }
            if(this.nextDriver == null && this.check){
                this.currentLowerRange = this.currentUpperRange;
                this.times++;
                this.currentUpperRange = 1 + this.times * this.step;
                this.iterablePool = pool.iterator();
                this.check = false;
            }
    }

    public boolean hasNext(){
        while(this.nextCount < this.poolSize && this.nextDriver == null){
            this.loadNext();
        }
        return this.nextDriver != null;
    }

    public Driver next(){
        Driver nextD;
        if(this.hasNext()){
            nextD = this.nextDriver;
            this.nextDriver = null;
            this.nextCount++;
        }
        else{
            throw new NoSuchElementException();
        }
        return nextD;
    }
}
