package com.comp301.a05driver;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ProximityIterator implements Iterator{
    private Driver nextDriver;
    private Iterator<Driver> iterablePool;
    private int range;
    private Position currentPos;

    public ProximityIterator(Iterable<Driver> driverPool, Position clientPosition, int proximityRange){
        if(driverPool == null || clientPosition == null){
            throw new IllegalArgumentException();
        }
        this.iterablePool = driverPool.iterator();
        this.nextDriver = null;
        this.range = proximityRange;
        this.currentPos = clientPosition;
    }

    private void loadNext(){
        while(this.nextDriver == null && this.iterablePool.hasNext()){
            Driver nextDriv = this.iterablePool.next();
            if(nextDriv.getVehicle().getPosition().getManhattanDistanceTo(currentPos) <= range){
                this.nextDriver = nextDriv;
            }
        }
    }

    public boolean hasNext(){
        this.loadNext();
        return this.nextDriver != null;
    }

    public Driver next(){
        Driver nextD;
        if(hasNext()){
            nextD = this.nextDriver;
            this.nextDriver = null;
        }
        else{
            throw new NoSuchElementException();
        }
        return nextD;
    }
}
