package com.comp301.a05driver;

import org.junit.Test;

import java.util.ArrayList;
import java.util.NoSuchElementException;

import static org.junit.Assert.*;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        ArrayList<Driver> drivers = new ArrayList<>();
        Position pos = new PositionImpl(1, 1);
        Position pos2 = new PositionImpl(6, 2);
        Position pos3 = new PositionImpl(4, 1);
        Vehicle car = new VehicleImpl("m", "1", "df", pos);
        Vehicle car2 = new VehicleImpl("n", "2", "dfg", pos2);
        Vehicle car3 = new VehicleImpl("n", "2", "dfg", pos3);
        Driver daniel = new DriverImpl("daniel", "fang", 1, car2);
        Driver hunter = new DriverImpl("hunter", "kouchi", 2, car3);
        Driver ethan = new DriverImpl("ethan", "kim", 3, car);
        drivers.add(daniel);
        drivers.add(hunter);
        drivers.add(ethan);
        ExpandingProximityIterator prox = new ExpandingProximityIterator(drivers, new PositionImpl(1,1), 3);
        assertEquals(ethan, prox.next());
        assertEquals(hunter, prox.next());
        assertEquals(daniel, prox.next());
    }
}
